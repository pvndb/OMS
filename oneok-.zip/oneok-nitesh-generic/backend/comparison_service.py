
# backend/comparison_service.py
from typing import List, Dict
import streamlit as st
import time
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
import logging
from backend.system_prompts import DIRECTORY_PROMPTS
# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

MODEL_ARN = st.secrets["MODEL_ARN"]
KNOWLEDGE_BASE_ID = st.secrets["KNOWLEDGE_BASE_ID"]

def process_document_comparison(prompt, query, searchtype_selected, selectedDirectory):
        """
        Retrieve and generate text using Amazon Bedrock agent runtime.

        Args:
            prompt (str): The prompt template
            query (str): The input query text
            searchtype_selected (str): The input search type

        Returns:
            str: Generated output text or None if an error occurs
        """
        # Define configuration constants
        DEFAULT_CONFIG = {
            "maxTokens": 2000,
            "temperature": 1.0,
            "topP": 0.9,
            "numberOfResults": 15
        }

        try:
            # Create progress bar
            progress_bar = st.progress(0)
            status_text = st.empty()

            # Update progress for initialization
            status_text.text("Initializing Bedrock client...")
            progress_bar.progress(0.2)


            # Create client with connection pooling
            boto_config = Config(
                retries={'max_attempts': 3},
                connect_timeout=5,
                read_timeout=30
            )
            session = boto3.Session()
            bedrock_client = session.client(
                "bedrock-agent-runtime",
                config=boto_config
            )

            # Update progress for request preparation
            status_text.text("Preparing request...")
            progress_bar.progress(0.4)

            # system_prompts = DIRECTORY_PROMPTS.get(selectedDirectory, "")
            # if system_prompts:
            #     combined_prompt = f"""{system_prompts}

            # {prompt}"""
            # else:
            #     combined_prompt = prompt  # Use original prompt if no system prompt exists


            # Prepare the request payload
            request_payload = {
                "input": {"text": query},
                "retrieveAndGenerateConfiguration": {
                    "knowledgeBaseConfiguration": {
                        "knowledgeBaseId": KNOWLEDGE_BASE_ID,
                        "modelArn": MODEL_ARN,
                        "generationConfiguration": {
                            "inferenceConfig": {
                                "textInferenceConfig": {
                                    "maxTokens": DEFAULT_CONFIG["maxTokens"],
                                    "temperature": DEFAULT_CONFIG["temperature"],
                                    "topP": DEFAULT_CONFIG["topP"],
                                }
                            },
                            "promptTemplate": {"textPromptTemplate": prompt},
                        },
                        "retrievalConfiguration": {
                            "vectorSearchConfiguration": {
                                "numberOfResults": DEFAULT_CONFIG["numberOfResults"],
                                'overrideSearchType': searchtype_selected
                            },
                        },
                    },
                    "type": "KNOWLEDGE_BASE",
                },
            }

            # Update progress for API call
            status_text.text("Generating response...")
            progress_bar.progress(0.6)

            # Make the API call
            response = bedrock_client.retrieve_and_generate(**request_payload)
            # Update progress for processing response
            status_text.text("Processing response...")
            progress_bar.progress(0.8)
            result = response.get("output", {}).get("text")

            # Complete the progress bar
            progress_bar.progress(1.0)
            status_text.text("Complete!")

            # Clear the progress indicators after a short delay
            time.sleep(0.5)
            progress_bar.empty()
            status_text.empty()

            return result

        except ClientError as e:
            if 'progress_bar' in locals():
                progress_bar.empty()
            if 'status_text' in locals():
                status_text.empty()
            logger.error(f"Bedrock API error: {str(e)}")
            st.error(f"Error calling Bedrock API: {str(e)}")
            return None
        except Exception as e:
            if 'progress_bar' in locals():
                progress_bar.empty()
            if 'status_text' in locals():
                status_text.empty()
            logger.error(f"Unexpected error: {str(e)}")
            st.error(f"An unexpected error occurred: {str(e)}")
            return None

