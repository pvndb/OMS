ASSET_INTEGRITY=f"""
"Compare and analyze the asset integrity management systems of Company A and Company B, focusing on the following aspects:

 Formulation and review of inspection, maintenance, and outage strategies:
- How do both companies align these strategies with health, safety, environment, operational integrity, and business objectives?
- What are the differences in their approaches to developing and documenting asset management strategies?

 Asset and equipment inventory management:
- Compare the methods used to create and manage inventories of assets and equipment.
- How do they determine and record the criticality and/or risk level of assets and equipment?

 Asset management plans throughout the lifecycle:
- Analyze the differences in how both companies establish and document asset management plans.
- Compare their approaches to identifying specific threats or failure modes and associated risks.

 Management of safety critical assets and equipment:
- How do both companies identify and manage registers of safety critical assets and equipment?
- Compare their processes for creating and managing standards for minimum integrity and reliability requirements.

 Use of enterprise systems for work management:
- Evaluate the differences in how both companies leverage enterprise systems for managing work identification, planning, inspections, and maintenance.
- Compare their approaches to prioritizing corrective actions and determining 'no later than' dates.

Provide a detailed analysis of the key differences, highlighting any gaps, strengths, or potential areas for improvement in each company's asset integrity management system."
"""

INCIDENT_MANAGEMENT=f"""
"Evaluate and compare the incident management processes of Company A and Company B, addressing the following aspects:

 Incident response and impact minimization:
- How do both companies approach the immediate response to incidents?
- Compare their strategies for minimizing impact on workforce health and safety, the environment, the public, and physical assets.

 Incident reporting and severity classification:
- Analyze the differences in incident reporting timeframes and methods.
- Compare how both companies classify actual and potential severity of incidents.

 Incident record verification and stakeholder notification:
- How do both companies verify incident records and their classification?
- Compare their processes for notifying relevant internal and external stakeholders.

 Incident investigation and root cause analysis:
- Evaluate the differences in investigation processes based on incident severity.
- Compare the methodologies used for root cause analysis and action implementation.

 Incident data analysis and trend identification:
- How do both companies analyze incident data to determine trends?
- Compare their approaches to identifying and implementing improvement opportunities.

 Communication and implementation of incident learnings:
- Analyze the differences in how both companies communicate incident learnings to the workforce.
- Compare their strategies for implementing relevant learnings from internal and external incidents.

Provide a comprehensive comparison of the incident management processes, highlighting key differences, strengths, and potential areas for improvement in each company's approach."
"""

ENVIRONMENT=f"""
"Compare and analyze the environmental management systems of Company A and Company B, focusing on the following aspects:

 Identification and recording of regulatory requirements:
- How do both companies identify and record existing, new, and impending regulatory requirements related to environmental protection?
- Compare their approaches to incorporating these requirements into their operations.

 Management of compliance activities and tasks:
- Analyze the differences in how both companies assign accountability for environmental compliance activities.
- Compare their processes for tracking and reporting the performance of these activities.

 Stakeholder engagement and commitment management:
- How do both companies identify and engage with external stakeholders and rights-holders on environmental matters?
- Compare their approaches to recording and demonstrating the fulfillment of environmental commitments.

 Communication of environmental risks and activities:
- Evaluate the differences in how both companies communicate relevant environmental risks and activities to external stakeholders.
- Compare their strategies for providing stakeholders with opportunities to be informed and seek clarification.

Provide a detailed analysis of the environmental management systems, highlighting key differences, strengths, and potential areas for improvement in each company's approach to environmental compliance and stakeholder engagement."
"""

SAFETY=f"""
"Compare and analyze the safety management systems of Company A and Company B, focusing on the following aspects:

Risk Management:
 Hazard identification and risk assessment:
- How do both companies identify hazards and assess their consequences and likelihood?
- Compare their use of risk matrices or similar tools for risk assessment.

 Risk control and documentation:
- Analyze the differences in how both companies apply the hierarchy of controls to manage risks.
- Compare their processes for documenting risks in risk registers.

Competency & Training:
 Role criticality assessment:
- How do both companies assess the criticality of roles relevant to safety?
- Compare their approaches to defining role descriptions and required competencies.

 Safety training and competence development:
- Evaluate the differences in how both companies provide safety training to workforce members.
- Compare their strategies for continually developing safety competence in the workforce.

Control of Work:
 Work authorization and permit systems:
- How do both companies manage the authorization of work, especially for high-hazard tasks?
- Compare their permit-to-work processes and requirements.

 Hazard identification and control in work planning:
- Analyze the differences in how both companies identify and control hazards associated with work activities.
- Compare their processes for verifying that controls are in place before work starts.

 Management of simultaneous operations and work stoppages:
- How do both companies manage risks associated with simultaneous operations?
- Compare their approaches to work stoppages and re-authorization when conditions change.

Provide a comprehensive comparison of the safety management systems, highlighting key differences, strengths, and potential areas for improvement in each company's approach to risk management, competency development, and control of work."
"""

DIRECTORY_PROMPTS = {
    "Element 05 - Safety Source Documents": SAFETY,
    "Element 06 - Environmental Source Documents": ENVIRONMENT,
    "Element 13 - Incident Management Source Documents": INCIDENT_MANAGEMENT
}