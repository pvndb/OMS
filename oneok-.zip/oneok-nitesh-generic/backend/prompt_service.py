import boto3

bedrock_client = boto3.client("bedrock-agent")

def list_prompts():
        return bedrock_client.list_prompts()["promptSummaries"]

def get_prompt(id: str, version: str):
    return bedrock_client.get_prompt(
        promptIdentifier=id, promptVersion=version
    )