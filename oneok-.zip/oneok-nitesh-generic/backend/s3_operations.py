# src/backend/s3_operations.py
from typing import Dict, List, Any, Set
import streamlit as st
import logging
import boto3
from botocore.exceptions import ClientError
from functools import wraps
import io

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Constants
ALLOWED_EXTENSIONS: Set[str] = frozenset({'.pdf', '.docx', '.doc'})
BUCKET_NAME: str = st.secrets["AWS_S3_BUCKET"]
DEFAULT_DELIMITER: str = '/'
ERROR_MESSAGES = {
    'NoSuchBucket': lambda bucket: f"Bucket '{bucket}' does not exist",
    'NoSuchKey': lambda path, bucket: f"Path '{path}' does not exist in bucket '{bucket}'",
}

def create_s3_client():
    """Create and return an S3 client"""
    return boto3.client('s3')

def handle_s3_errors(func):
    """Decorator to handle S3 client errors"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ClientError as e:
            error_code = e.response['Error']['Code']
            context = kwargs.get('directory', 'root directory')
            bucket = kwargs.get('bucket_name')

            if error_code == 'NoSuchBucket':
                error_message = ERROR_MESSAGES['NoSuchBucket'](bucket)
            elif error_code == 'NoSuchKey':
                error_message = ERROR_MESSAGES['NoSuchKey'](context, bucket)
            else:
                error_message = f"S3 operation failed: {str(e)}"

            logger.error(error_message)
            raise Exception(error_message)
    return wrapper

def is_valid_file(file_name: str) -> bool:
    """
    Check if file has allowed extension

    Args:
        file_name (str): Name of the file to check
    Returns:
        bool: True if file has allowed extension
    """
    return any(file_name.lower().endswith(ext) for ext in ALLOWED_EXTENSIONS)

def get_s3_objects(s3_client: Any, bucket_name: str, prefix: str) -> List[dict]:
    """
    Get S3 objects using pagination

    Args:
        s3_client: Boto3 S3 client
        bucket_name (str): Name of the S3 bucket
        prefix (str): The S3 prefix to list objects from
    Returns:
        List[dict]: List of S3 objects
    """
    objects = []
    paginator = s3_client.get_paginator('list_objects_v2')

    for page in paginator.paginate(Bucket=bucket_name, Prefix=prefix):
        if 'Contents' in page:
            objects.extend(page['Contents'])

    return objects

@handle_s3_errors
def list_directories() -> Dict[str, str]:
    """
    List all directories in the S3 bucket

    Args:
        bucket_name (str): Name of the S3 bucket
    Returns:
        Dict[str, str]: Dictionary of directory names and paths
    """
    s3_client = create_s3_client()

    response = s3_client.list_objects_v2(
        Bucket=BUCKET_NAME,
        Delimiter=DEFAULT_DELIMITER
    )

    directories = {}

    if 'CommonPrefixes' in response:
        for prefix in response['CommonPrefixes']:
            dir_name = prefix['Prefix'].rstrip(DEFAULT_DELIMITER)
            directories[dir_name] = dir_name

    if not directories:
        directories["default"] = "Default Directory"

    logger.info(f"Found {len(directories)} directories")
    return directories

@handle_s3_errors
def list_files_from_directory(directory: str) -> List[str]:
    """
    Lists all PDF and DOCX files from a specific directory in S3

    Args:
        directory (str): Path of the directory in S3
    Returns:
        List[str]: Sorted list of file names
    Raises:
        ValueError: If directory path is empty
        Exception: If S3 operations fail
    """
    if not directory:
        raise ValueError("Directory path cannot be empty")

    s3_client = create_s3_client()

    # Normalize directory path
    prefix = f"{directory.rstrip(DEFAULT_DELIMITER)}{DEFAULT_DELIMITER}"

    # Get all objects from S3
    s3_objects = get_s3_objects(s3_client, BUCKET_NAME, prefix)

    # Process and filter files
    files = []
    for obj in s3_objects:
        file_path = obj['Key']

        # Skip if it's the directory itself
        if file_path == prefix:
            continue

        file_name = file_path.replace(prefix, '')
        if is_valid_file(file_name):
            files.append(file_name)

    logger.info(f"Found {len(files)} valid files in directory '{directory}'")
    return sorted(files)

def process_file_batch(files: List[str], batch_size: int = 100) -> List[List[str]]:
    """
    Process files in batches

    Args:
        files (List[str]): List of files to process
        batch_size (int): Size of each batch
    Returns:
        List[List[str]]: List of file batches
    """
    return [files[i:i + batch_size] for i in range(0, len(files), batch_size)]

def validate_s3_path(bucket_name: str, directory: str) -> bool:
    """
    Validate S3 path exists

    Args:
        bucket_name (str): Name of the S3 bucket
        directory (str): Directory path to validate
    Returns:
        bool: True if path exists
    """
    try:
        s3_client = create_s3_client()
        s3_client.head_object(Bucket=bucket_name, Key=directory.rstrip('/') + '/')
        return True
    except ClientError:
        return False

def get_file_metadata(bucket_name: str, file_path: str) -> Dict[str, Any]:
    """
    Get metadata for a specific file

    Args:
        bucket_name (str): Name of the S3 bucket
        file_path (str): Path to the file
    Returns:
        Dict[str, Any]: File metadata
    """
    try:
        s3_client = create_s3_client()
        response = s3_client.head_object(Bucket=bucket_name, Key=file_path)
        return {
            'size': response['ContentLength'],
            'last_modified': response['LastModified'],
            'content_type': response.get('ContentType', 'unknown'),
            'metadata': response.get('Metadata', {})
        }
    except ClientError as e:
        logger.error(f"Error getting metadata for {file_path}: {e}")
        return {}


def upload_to_s3(file, directory, bucket_name):
    """
    Upload a file to a specific directory in an S3 bucket
    """
    try:
        s3_client = boto3.client(
                    service_name="s3",
                    aws_access_key_id=st.secrets["AWS_ACCESS_KEY_ID"],
                    aws_secret_access_key=st.secrets["AWS_SECRET_ACCESS_KEY"],
                    region_name=st.secrets["AWS_REGION"],
                    aws_session_token=st.secrets["AWS_SESSION_TOKEN"]
                )
        # Create the S3 key (path) by combining directory and filename
        s3_key = f"{directory}/{file.name}"

        # Read the file into memory
        bytes_data = file.getvalue()
        file_obj = io.BytesIO(bytes_data)

        s3_client.upload_fileobj(
            Fileobj=file_obj,
            Bucket=bucket_name,
            Key=s3_key
        )


        # Generate the S3 URL
        url = f"https://{bucket_name}.s3.amazonaws.com/{s3_key}"

        return {
            "status": "success",
            "message": f"**{s3_key}** File uploaded successfully",
            "url": url,
            "key": s3_key
        }

    except ClientError as e:
        return {
            "status": "error",
            "message": f"AWS Error: {str(e)}"
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"An unexpected error occurred: {str(e)}"
        }
    finally:
        if 'file_obj' in locals():
            file_obj.close()