# constants/bedrock_prompts.py

from enum import Enum
from typing import Dict, Optional

class EnergyDocumentElement(Enum):
    SAFETY = "safety_management"
    ASSET_INTEGRITY = "asset_integrity"
    INCIDENT_MANAGEMENT = "incident_management"
    ENVIRONMENTAL = "environmental"

class EnergySectorPrompts:
    # Base context for energy sector document harmonization
    BASE_CONTEXT = """You are an expert energy sector document analyst specializing in the harmonization of operational
    procedures, standards, and policies between Roanoke and legacy Magellan operations. Your primary focus is on:

    1. Identifying operational best practices from both organizations
    2. Understanding regulatory compliance requirements across jurisdictions
    3. Maintaining safety and environmental standards
    4. Ensuring operational continuity during integration
    5. Standardizing reporting and documentation practices

    Consider the following during analysis:
    - Industry-specific terminology and definitions
    - Regulatory requirements across different operating regions
    - Historical incident data and lessons learned
    - Current operational constraints and capabilities
    - Integration impact on existing processes"""

    ELEMENT_CONTEXTS: Dict[EnergyDocumentElement, str] = {
        EnergyDocumentElement.SAFETY: """Analyze safety management systems and procedures focusing on:

        Critical Areas of Focus:
        - Personal and Process Safety Management (PSM) requirements
        - Safety critical equipment and systems
        - Emergency response procedures and responsibilities
        - Training and competency requirements
        - Risk assessment methodologies
        - Management of Change (MOC) procedures
        - Contractor safety management
        - Safety performance metrics and KPIs

        Integration Considerations:
        - Identify stronger safety protocols between Roanoke and Magellan
        - Evaluate effectiveness of current safety programs
        - Compare incident prevention strategies
        - Assess safety culture elements
        - Review safety communication protocols

        Harmonization Objectives:
        1. Create unified safety standards meeting highest requirements
        2. Standardize safety reporting and metrics
        3. Align emergency response protocols
        4. Develop consistent training requirements
        5. Establish common risk assessment methodology""",

        EnergyDocumentElement.ASSET_INTEGRITY: """Analyze asset integrity management systems focusing on:

        Critical Areas of Focus:
        - Equipment inspection and testing protocols
        - Preventive maintenance programs
        - Corrosion management systems
        - Pipeline integrity management
        - Storage tank management
        - Critical equipment classification
        - Life cycle asset management
        - Technology and monitoring systems

        Integration Considerations:
        - Compare asset management strategies
        - Evaluate maintenance philosophies
        - Review equipment standards
        - Assess inspection frequencies
        - Analyze failure prevention approaches

        Harmonization Objectives:
        1. Standardize asset classification system
        2. Align maintenance intervals and procedures
        3. Unify integrity monitoring practices
        4. Establish common equipment standards
        5. Develop integrated asset lifecycle approach""",

        EnergyDocumentElement.INCIDENT_MANAGEMENT: """Analyze incident management systems focusing on:

        Critical Areas of Focus:
        - Incident classification and reporting
        - Investigation methodologies
        - Root cause analysis procedures
        - Corrective action tracking
        - Near-miss reporting
        - Learning from incidents
        - Communication protocols
        - Regulatory reporting requirements

        Integration Considerations:
        - Compare incident investigation approaches
        - Evaluate reporting thresholds
        - Review communication procedures
        - Assess corrective action effectiveness
        - Analyze trending methodologies

        Harmonization Objectives:
        1. Establish unified incident classification
        2. Standardize investigation procedures
        3. Align reporting requirements
        4. Create common learning framework
        5. Develop integrated tracking system""",

        EnergyDocumentElement.ENVIRONMENTAL: """Analyze environmental management systems focusing on:

        Critical Areas of Focus:
        - Environmental compliance requirements
        - Emissions monitoring and reporting
        - Waste management procedures
        - Spill prevention and response
        - Environmental impact assessments
        - Sustainability initiatives
        - Environmental performance metrics
        - Regulatory reporting requirements

        Integration Considerations:
        - Compare environmental standards
        - Evaluate monitoring practices
        - Review reporting procedures
        - Assess mitigation strategies
        - Analyze sustainability approaches

        Harmonization Objectives:
        1. Unify environmental standards
        2. Align monitoring protocols
        3. Standardize reporting methods
        4. Integrate sustainability practices
        5. Establish common metrics"""
    }

    # Bedrock specific parameters for consistent responses
    BEDROCK_PARAMS = {
        "anthropic_version": "bedrock-2024-02-29",
        "max_tokens": 4096,
        "temperature": 0.1,
        "top_p": 0.9,
        "stop_sequences": None
    }

    @staticmethod
    def get_analysis_prompt(element_type: EnergyDocumentElement,
                          doc1: str,
                          doc2: str,
                          specific_focus: Optional[str] = None) -> str:
        """Generate analysis prompt for Bedrock"""

        prompt = f"""Context: {EnergySectorPrompts.BASE_CONTEXT}

Element Focus: {EnergySectorPrompts.ELEMENT_CONTEXTS[element_type]}

Document 1:
{doc1}
Document 2:
{doc2}

{specific_focus if specific_focus else ''}
"""

        return prompt

    @staticmethod
    def create_bedrock_request(prompt: str) -> Dict:
        """Create formatted request for Bedrock"""
        return {
            **EnergySectorPrompts.BEDROCK_PARAMS,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": prompt
                        }
                    ]
                }
            ]
        }

# Example usage in your retrieval code:
# """
# from constants.bedrock_prompts import EnergyDocumentElement, EnergySectorPrompts

# def retrieve_from_bedrock(element_type: EnergyDocumentElement, doc_info: str):
#     # Create prompt
#     prompt = EnergySectorPrompts.get_analysis_prompt(
#         element_type=element_type,
#         source_doc_info=doc_info
#     )

#     # Create Bedrock request
#     request = EnergySectorPrompts.create_bedrock_request(prompt)

#     # Make Bedrock API call
#     response = bedrock_runtime.invoke_model(
#         modelId='anthropic.claude-3.5-sonnet-20240229-v1',
#         body=json.dumps(request)
#     )

#     return response
# """
