import streamlit as st

def set_page_configuration():
    st.set_page_config(
        page_title="My Application",
        layout="wide",  # Set wide layout
        initial_sidebar_state="collapsed"
    )

def hide_deploy_buttons():
    st.markdown("""
    <style>
        .reportview-container {
            margin-top: 5em;
        }
        #MainMenu {visibility: hidden;}
        .stDeployButton {display:none;}
        footer {visibility: hidden;}
        #stDecoration {display:none;}
    </style>
""", unsafe_allow_html=True)

    st.markdown("""
        <style>
        /* Hide deploy button */
        .stDeployButton {
            display: none !important;
        }

        /* Hide rerun button */
        .stToolbar {
            display: none !important;
        }

        /* Hide hamburger menu */
        #MainMenu {
            display: none !important;
        }

        /* Hide footer */
        footer {
            display: none !important;
        }

        /* Reset top margins and padding */
        .main > div {
            padding-top: 0rem;
        }

        .block-container {
            padding-top: 1rem !important;
            margin-top: 0.5rem !important;
        }

        /* Hide deploy iframe */
        iframe[title="deployment"] {
            display: none !important;
        }

        div[data-testid="stDecoration"] {
            display: none !important;
        }

        /* Header styling */
        .header-container {
            display: flex;
            align-items: center;
            background-color: #ffffff;
            padding: 1rem 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .logo-img {
            height: 50px;
            margin-right: 2rem;
        }

        .menu-container {
            display: flex;
            align-items: center;
            gap: 2rem;
        }

        /* Style for the tabs to appear in line with logo */
        .stTabs {
            margin-top: -1rem;
        }

        .stTabs [data-baseweb="tab-list"] {
            gap: 24px;
        }

        .stTabs [data-baseweb="tab"] {
            height: 50px;
            padding: 0 24px;
            background-color: #ffffff;
            border-radius: 4px;
        }
        </style>
    """, unsafe_allow_html=True)

def create_header_with_tabs():
    # Create columns with specific ratios for better layout
    col1, col2 = st.columns([1, 4])

    with col1:
        # Replace with your logo path
        st.image("logo.png", width=150)

    with col2:
        # Create tabs
        tabs = st.tabs(["Dashboard", "Analytics", "Reports", "Settings"])

        with tabs[0]:
            st.header("Dashboard")
            dash_col1, dash_col2, dash_col3 = st.columns(3)
            with dash_col1:
                st.metric(label="Revenue", value="$150K", delta="15%")
            with dash_col2:
                st.metric(label="Users", value="1.2K", delta="10%")
            with dash_col3:
                st.metric(label="Conversion", value="25%", delta="-5%")

        with tabs[1]:
            st.header("Analytics")
            st.line_chart({"data": [1, 5, 2, 6, 2, 1]})

        with tabs[2]:
            st.header("Reports")
            st.write("Reports content goes here")

        with tabs[3]:
            st.header("Settings")
            st.write("Settings content goes here")

def main():
    # Must be the first Streamlit command
    set_page_configuration()

    # Hide deploy buttons and other elements
    hide_deploy_buttons()

    # Create header with tabs
    create_header_with_tabs()

if __name__ == "__main__":
    main()
