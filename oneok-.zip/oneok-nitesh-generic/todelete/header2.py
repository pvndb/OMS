import streamlit as st

def create_header_with_tabs():
    st.title("My Application")

    # Custom CSS for tabs
    st.markdown("""
        <style>
        .stTabs [data-baseweb="tab-list"] {
            gap: 24px;
        }
        .stTabs [data-baseweb="tab"] {
            height: 50px;
            padding: 0 24px;
            background-color: #ffffff;
            border-radius: 4px;
        }
        </style>
    """, unsafe_allow_html=True)

    # Create tabs
    tab1, tab2, tab3, tab4 = st.tabs(["Dashboard", "Analytics", "Reports", "Settings"])

    with tab1:
        st.header("Dashboard")
        st.write("Dashboard content goes here")

    with tab2:
        st.header("Analytics")
        st.write("Analytics content goes here")

    with tab3:
        st.header("Reports")
        st.write("Reports content goes here")

    with tab4:
        st.header("Settings")
        st.write("Settings content goes here")

if __name__ == "__main__":
    create_header_with_tabs()
