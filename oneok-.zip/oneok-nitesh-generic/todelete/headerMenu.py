import streamlit as st

def create_header():
    # Custom CSS for styling
    st.markdown("""
        <style>
        .header-container {
            padding: 1rem;
            background-color: #f0f2f6;
            border-radius: 0.5rem;
            margin-bottom: 2rem;
        }
        .menu-container {
            display: flex;
            justify-content: center;
            gap: 2rem;
            margin-top: 1rem;
        }
        </style>
    """, unsafe_allow_html=True)

    # Header container
    st.markdown('<div class="header-container">', unsafe_allow_html=True)

    # Title
    st.title("My Application")

    # Create menu using columns
    menu_cols = st.columns(4)

    with menu_cols[0]:
        if st.button("Dashboard"):
            st.session_state.page = "dashboard"

    with menu_cols[1]:
        if st.button("Analytics"):
            st.session_state.page = "analytics"

    with menu_cols[2]:
        if st.button("Reports"):
            st.session_state.page = "reports"

    with menu_cols[3]:
        if st.button("Settings"):
            st.session_state.page = "settings"

    st.markdown('</div>', unsafe_allow_html=True)

def main():
    # Initialize session state for page tracking
    if 'page' not in st.session_state:
        st.session_state.page = "dashboard"

    # Render header
    create_header()

    # Content based on selected page
    if st.session_state.page == "dashboard":
        st.header("Dashboard")
        st.write("Welcome to the dashboard!")

    elif st.session_state.page == "analytics":
        st.header("Analytics")
        st.write("Analytics content goes here")

    elif st.session_state.page == "reports":
        st.header("Reports")
        st.write("Reports content goes here")

    elif st.session_state.page == "settings":
        st.header("Settings")
        st.write("Settings content goes here")

if __name__ == "__main__":
    main()
