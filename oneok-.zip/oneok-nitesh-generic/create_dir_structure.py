import os

def create_directory_structure():
    # Define the base structure
    structure = {
        'src': {
            'frontend': {
                '__init__.py': '',
                'components.py': '',
                'ui_handlers.py': '',
                'views.py': ''
            },
            'backend': {
                '__init__.py': '',
                's3_operations.py': '',
                'prompt_service.py': ''
            },
            'common': {
                '__init__.py': '',
                'models.py': '',
                'constants.py': '',
                'utils.py': ''
            },
            'main.py': ''
        }
    }

    def create_structure(base_path, structure):
        for name, content in structure.items():
            path = os.path.join(base_path, name)
            if isinstance(content, dict):
                # If it's a directory
                os.makedirs(path, exist_ok=True)
                create_structure(path, content)
            else:
                # If it's a file
                with open(path, 'w') as f:
                    f.write(content)

    # Create the structure
    create_structure('.', structure)
    print("Directory structure created successfully!")

# Run the function
if __name__ == "__main__":
    create_directory_structure()
