# src/frontend/components.py
import streamlit as st
import pandas as pd
from typing import Dict, Optional, List
import streamlit as st
from frontend.components.upload_file import show_upload_form

def create_action_buttons() -> None:
    # Create columns with specific ratios
    button_col1, button_col2, space_col = st.columns([1.2, 1.2, 4])

    with button_col1:
        if st.button(
            "📂 Upload File",
            key="upload_btn",
            use_container_width=True
        ):
            show_upload_form()

    with button_col2:
        if st.button(
            "⟳ Refresh",
            key="refresh_btn",
            use_container_width=True
        ):
            st.cache_data.clear()

def create_directory_selector(directories: Dict[str, str]) -> Optional[str]:
    if not directories:
        st.warning("No directories available")
        return None

    return st.pills(
        "Directories",
        options=list(directories.keys()),
        format_func=lambda option: directories[option],
        selection_mode="single",
    )

def create_file_selector(files: List[str], directory: str) -> Optional[List[str]]:
    """
    Create a Streamlit file selector widget with checkboxes
    """
    if not files:
        st.warning(f"No files found in directory: {directory}")
        return None

    MAX_SELECTIONS = 3
    # Create DataFrame for display
    df = pd.DataFrame({
        "✓": [False] * len(files),  # Checkbox column
        "File Name": files,
    })

    st.write(f"### Files in {directory}")

    # Create dataframe with checkbox selection
    edited_df = st.data_editor(
        df,
        column_config={
            "✓": st.column_config.CheckboxColumn(
                "✓",
                width=20,
                required=True,
                help=f"Select up to {MAX_SELECTIONS} files"
            ),
            "File Name": st.column_config.TextColumn(
                "File Name",
                help="Name of the document",
                width="large"
            )
        },
        hide_index=True,
        use_container_width=True,
        disabled=["File Name"],
        key="file_selector",
        on_change=None
    )

    # Get selected files directly from the DataFrame
    selected_files = edited_df[edited_df["✓"]]["File Name"].tolist()
    # Check if more than MAX_SELECTIONS files are selected
    if len(selected_files) > MAX_SELECTIONS:
        st.error(f"Select up to maximum {MAX_SELECTIONS} documents for review. Currently selected: {len(selected_files)}")

    return selected_files if selected_files else None
