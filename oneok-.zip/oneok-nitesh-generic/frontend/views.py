# src/frontend/views.py
import streamlit as st
import logging
import re
from typing import Dict
from frontend.ui_components import create_directory_selector, create_file_selector, create_action_buttons
from backend.s3_operations import list_directories, list_files_from_directory
from backend.comparison_service import process_document_comparison
# from backend.prompt_service import BedrockPrompt
from frontend.components.prompt_selector import render_prompt_selection_ui
from frontend.components.file_selector import create_file_selector
from common.utils import format_error_message
from common.notification import show_warning
from common.cache import st_cache_data
from backend.system_prompts import DIRECTORY_PROMPTS
from backend.bedrock_prompts import EnergyDocumentElement, EnergySectorPrompts

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def render_document_comparison_view(bucket_name: str):
    """
    Render the main document comparison view

    Args:
        bucket_name (str): S3 bucket name
    """
    st.title("Document Comparison Tool")

    create_action_buttons()
    directories = list_directories()
    # Add error handling and default empty dict
    if directories is None:
        st.error("Unable to fetch directories from S3")
        directories = {}  # Provide empty dict as fallback


    selectedDirectory = create_directory_selector(directories)
    if(selectedDirectory is None):
        show_warning("Please select a directory for the operation.")
        return
    else:
        files = list_files_from_directory(selectedDirectory)
        selected_files = create_file_selector(files, selectedDirectory)

        if selected_files:
            # Prompt selectedDirectory section
            st.header("Configure Comparison")
            selected_prompt_config = render_prompt_selection_ui(selected_files)

            # st.write("Selected Configuration:", selected_prompt_config)
            if selected_prompt_config:
                # Create two equal columns
                # system_prompts = DIRECTORY_PROMPTS.get(selectedDirectory, "")

                prompt_template = selected_prompt_config["config"]["variants"][0]["templateConfiguration"]["text"][
                        "text"
                    ]

                doc1 = selected_files[0]
                doc2 = selected_files[1]
                doc3 = None
                if len(selected_files) == 3:
                    doc3 = selected_files[2]

                # Prepare the optional Document 3 section
                doc3_section = f"Document 3: {doc3}" if doc3 else ""
                # Create a dictionary of replacements
                replacements = {
                    "{{input1}}": doc1,
                    "{{input2}}": doc2,
                    "{{doc3_section}}": doc3_section
                }

                # If input3 is provided, add it to the replacements
                if doc3:
                    replacements["{{input3}}"] = doc3
                else:
                    # Remove any remaining {{input3}} placeholder
                    prompt_template = re.sub(r'\{\{input3\}\}', '', prompt_template)
                    prompt_template = re.sub(r'\{\{doc3_section\}\}', '', prompt_template)

                # Replace placeholders in the template
                filled_prompt = prompt_template

                for placeholder, value in replacements.items():
                    filled_prompt = filled_prompt.replace(placeholder, value)

                if(selectedDirectory == "Element 05 - Safety Source Documents"):
                    selectedDirectory = EnergyDocumentElement.SAFETY
                elif(selectedDirectory == "Element 06 - Environmental Source Documents"):
                    selectedDirectory = EnergyDocumentElement.ENVIRONMENT
                elif(selectedDirectory == "Element 13 - Incident Management Source Documents"):
                    selectedDirectory = EnergyDocumentElement.INCIDENT_MANAGEMENT
                # Create prompt
                system_prompts = EnergySectorPrompts.get_analysis_prompt(
                    element_type=selectedDirectory,
                    doc1=doc1,
                    doc2=doc2
                )

                filled_prompt = (
                    system_prompts +
                    "\n"
                    + filled_prompt
                    + "\n"
                    + """
                    $search_results$
                    """
                )

                # st.write("Prompt Template:", filled_prompt)

                @st.dialog("Propmpt Template")
                def vote(item):
                    st.write(item)
                    if st.button("Close"):
                        st.rerun()

                col1, col2 = st.columns(2)
                with col1:
                    if st.button("Check prompt templates", key="check_btn", use_container_width=True):
                        vote(filled_prompt)

                with col2:
                    compare_button_submit = st.button("Compare Documents", key="compare_btn", use_container_width=True)
                if compare_button_submit:
                    try:
                        query = "Provide a comparison for these two documents"
                        searchtype_selected = selected_prompt_config["search_type"]
                        comparison_result = process_document_comparison(filled_prompt, query, searchtype_selected, selectedDirectory)

                        st.subheader("📊 Analysis Results", divider="gray")
                        html_string = f"""<div class="document-analysis">{comparison_result}</div>"""

                        st.markdown(html_string, unsafe_allow_html=True)

                        # st.markdown(comparison_result)

                    except Exception as e:
                        st.error(f"Error analyzing documents: {str(e)}")
                        logger.error(f"Analysis error: {e}", exc_info=True)
