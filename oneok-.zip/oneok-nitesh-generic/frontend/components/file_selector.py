
# frontend/components/file_selector.py
from typing import List, Optional
import streamlit as st
import pandas as pd
from common.notification import show_warning

MAX_SELECTIONS = 3

def create_file_selector(files: List[str], directory: str) -> Optional[List[str]]:
    """
    Create a file selector with checkboxes

    Args:
        files (List[str]): List of available files
        directory (str): Directory name for display

    Returns:
        Optional[List[str]]: Selected files or None
    """
    if not files:
        st.warning(f"No files found in {directory}")
        show_warning(f"No files found in {directory}")
        return None

    df = create_file_dataframe(files)
    selected_files = render_file_selector(df, directory)
    return validate_file_selection(selected_files)

def create_file_dataframe(files: List[str]) -> pd.DataFrame:
    """
    Create DataFrame for file selection

    Args:
        files (List[str]): List of files

    Returns:
        pd.DataFrame: DataFrame with files
    """
    return pd.DataFrame({
        "✓": [False] * len(files),
        "File Name": files,
    })

def render_file_selector(df: pd.DataFrame, directory: str) -> List[str]:
    """
    Render file selector interface

    Args:
        df (pd.DataFrame): DataFrame with files
        directory (str): Directory name

    Returns:
        List[str]: Selected files
    """
    # st.write(f"### Files in {directory}")
    # st.write("(Select up to 3 files)")

    edited_df = st.data_editor(
        df,
        column_config={
            "✓": st.column_config.CheckboxColumn(
                "✓",
                width=20,
                required=True,
                help=f"Select up to {MAX_SELECTIONS} files"
            ),
            "File Name": st.column_config.TextColumn(
                "File Name",
                help="Name of the document",
                width="large"
            )
        },
        hide_index=True,
        use_container_width=True,
        disabled=["File Name"],
        key="file_selector",
        on_change=None
    )

    return edited_df[edited_df["✓"]]["File Name"].tolist()

def validate_file_selection(selected_files: List[str]) -> Optional[List[str]]:
    """
    Validate file selection

    Args:
        selected_files (List[str]): Selected files

    Returns:
        Optional[List[str]]: Validated selection or None
    """
    if len(selected_files) > MAX_SELECTIONS:
        show_warning(f"Select up to maximum {MAX_SELECTIONS} documents for review. Currently selected: {len(selected_files)}")
        return None
    elif len(selected_files) < 2:
        show_warning("Please select at least 2 files")
        return None

    return selected_files