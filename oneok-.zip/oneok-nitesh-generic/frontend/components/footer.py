import streamlit as st

def create_footer():
    st.markdown("""
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-left">
                    <p class="footer-text">© 2024 Oneok</p>
                    <p class="footer-text">Version 1.0.0</p>
                </div>
                <div class="footer-right">
                    <a href="#" class="footer-link">Privacy Policy</a>
                    <span class="footer-divider">|</span>
                    <a href="#" class="footer-link">Terms of Service</a>
                    <span class="footer-divider">|</span>
                    <a href="#" class="footer-link">Contact Support</a>
                </div>
            </div>
        </div>
    """, unsafe_allow_html=True)
