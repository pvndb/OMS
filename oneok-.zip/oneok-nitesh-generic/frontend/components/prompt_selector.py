
# frontend/components/prompt_selector.py
from typing import Dict, List, Optional, Tuple
import streamlit as st
from backend.prompt_service import list_prompts, get_prompt
from functools import lru_cache

@lru_cache(maxsize=1)
def fetch_bedrock_prompts() -> List[Dict]:
    """
    Fetch and cache bedrock prompts

    Returns:
        List[Dict]: List of available prompts
    """
    return list_prompts()

def get_prompt_options(prompts: List[Dict]) -> List[str]:
    """
    Get list of prompt names

    Args:
        prompts (List[Dict]): List of prompts

    Returns:
        List[str]: List of prompt names
    """
    return sorted(set(prompt["name"] for prompt in prompts))

def get_versions_for_prompt(prompts: List[Dict], prompt_name: str) -> List[str]:
    """
    Get versions for selected prompt

    Args:
        prompts (List[Dict]): List of prompts
        prompt_name (str): Selected prompt name

    Returns:
        List[str]: Available versions
    """
    return sorted(
        prompt["version"]
        for prompt in prompts
        if prompt["name"] == prompt_name
    )

def create_selection_columns() -> Tuple:
    """
    Create columns with custom styling

    Returns:
        Tuple: Column objects
    """
    st.markdown("""
        <style>
        .stSelectbox {
            margin-bottom: 1rem;
        }
        </style>
    """, unsafe_allow_html=True)

    return st.columns(3)

def process_selected_documents(selected_files: List[str]) -> Tuple[str, str, Optional[str]]:
    """
    Process selected documents

    Args:
        selected_files (List[str]): Selected files

    Returns:
        Tuple[str, str, Optional[str]]: Processed document selections
    """
    doc1 = selected_files[0]
    doc2 = selected_files[1]
    doc3 = selected_files[2] if len(selected_files) > 2 else None
    return doc1, doc2, doc3

def render_prompt_selection_ui(selected_files: List[str]) -> Optional[Dict]:
    """
    Render prompt selection interface

    Args:
        selected_files (List[str]): Selected document files

    Returns:
        Optional[Dict]: Selection configuration if successful
    """
    try:
        # Get cached prompts
        bedrock_prompts = fetch_bedrock_prompts()

        # Process selected documents
        doc1, doc2, doc3 = process_selected_documents(selected_files)

        # Create columns
        col1, col2, col3 = create_selection_columns()

        with col1:
            # Prompt selection
            prompt_options = get_prompt_options(bedrock_prompts)
            prompt_selected = st.selectbox(
                "Select Prompt",
                prompt_options,
                key="prompt_selector"
            )

        with col2:
            # Search type selection
            search_type = st.selectbox(
                "Select search type",
                ["HYBRID", "SEMANTIC"],
                key="search_type_selector"
            )

        with col3:
            # Version selection
            versions = get_versions_for_prompt(bedrock_prompts, prompt_selected)
            version_selected = st.selectbox(
                "Select Version",
                versions,
                key="version_selector"
            )

            # Get prompt configuration
            prompt_id = next(
                (prompt["id"]
                 for prompt in bedrock_prompts
                 if prompt["name"] == prompt_selected
                 and prompt["version"] == version_selected),
                None
            )

            if not prompt_id:
                st.error("Invalid prompt selection")
                return None

            prompt_config = get_prompt(prompt_id, version_selected)
            if not prompt_config:
                st.error("Failed to fetch prompt configuration")
                return None

        # Return selection configuration
        return {
            "config": prompt_config,
            "search_type": search_type,
            "documents": (doc1, doc2, doc3)
        }

    except Exception as e:
        st.error(f"Error in prompt selection: {str(e)}")
        return None

