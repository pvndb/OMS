import streamlit as st
from pathlib import Path
import base64

def load_css(css_file):
    with open(css_file) as f:
        return f'<style>{f.read()}</style>'

def get_image_base64(image_path):
    with open(image_path, "rb") as img_file:
        return base64.b64encode(img_file.read()).decode()

def create_horizontal_menu():
    # Get current page from session state
    if 'current_page' not in st.session_state:
        st.session_state.current_page = 'Home'

    # Create a container for the header
    with st.container():
        # Load and inject CSS
        css_path = Path(__file__).parent / "../../styles" / "header.css"
        st.markdown(load_css(css_path), unsafe_allow_html=True)

        # Get logo path and convert to base64
        logo_path = Path(__file__).parent / "../../assets" / "oneok-logo.png"
        logo_base64 = get_image_base64(logo_path)

        # Header HTML with logo and menu
        header_html = f"""
        <div class="header-container">
            <img src="data:image/png;base64,{logo_base64}" class="logo-img">
            <div class="menu-container">
                <button class="menu-button {'active' if st.session_state.current_page == 'Home' else ''}"
                    onclick="handleClick('Home')"><span>🏠 Home</span></button>
                <button class="menu-button {'active' if st.session_state.current_page == 'Compare' else ''}"
                    onclick="handleClick('Compare')">Compare</button>
                <button class="menu-button {'active' if st.session_state.current_page == 'History' else ''}"
                    onclick="handleClick('History')">History</button>
                <button class="menu-button {'active' if st.session_state.current_page == 'Settings' else ''}"
                    onclick="handleClick('Settings')">Settings</button>
            </div>
        </div>

        <script>
        function handleClick(page) {{
            window.parent.postMessage({{
                type: 'streamlit:setComponentValue',
                value: page
            }}, '*');
        }}
        </script>
        """

        # Render the header
        st.markdown(header_html, unsafe_allow_html=True)

        # Handle menu clicks using streamlit components
        components = st.components.v1.html(
            "",
            height=0
        )

        if components:
            st.session_state.current_page = components