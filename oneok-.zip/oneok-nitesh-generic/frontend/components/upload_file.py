import streamlit as st
from backend.s3_operations import upload_to_s3

def validate_form(doc_type, file):
    errors = {}

    if not doc_type:
        errors['doc_type'] = "Please select a document type"

    if not file:
        errors['file'] = "Please upload a file"
    elif file:
        if file.size > 5 * 1024 * 1024:  # 5MB limit
            errors['file'] = "File size should be less than 5MB"

        allowed_types = ['pdf', 'docx']
        file_type = file.name.split('.')[-1].lower()
        if file_type not in allowed_types:
            errors['file'] = f"File type must be one of: {', '.join(allowed_types)}"

    return errors


@st.dialog("Upload Document")
def show_upload_form():
    # Get S3 bucket name from environment variable
    BUCKET_NAME = st.secrets["AWS_S3_BUCKET"]
    with st.form("upload_form", clear_on_submit=False):
        # st.markdown('<div class="form-container">', unsafe_allow_html=True)

        # Document Type Dropdown
        st.markdown('<p class="field-label required-field">Directory</p>', unsafe_allow_html=True)

        directory = st.selectbox(
            'Choose Directory',
            ('', 'Element-05', 'Element-06', 'Element-07', 'Element-08'),
            index=0,
            label_visibility="collapsed"
        )

        # Add some spacing
        st.markdown('<div style="height: 1rem"></div>', unsafe_allow_html=True)

        # File Upload
        st.markdown('<p class="field-label required-field">Upload File</p>', unsafe_allow_html=True)
        uploaded_file = st.file_uploader(
            "Upload your document",
            type=['pdf', 'docx'],
            label_visibility="collapsed"
        )

        # Add some spacing
        st.markdown('<div style="height: 1rem"></div>', unsafe_allow_html=True)

        submitted = st.form_submit_button("📤 Upload to S3", use_container_width=True)

        st.markdown('</div>', unsafe_allow_html=True)
        if submitted:
            errors = validate_form(directory, uploaded_file)

            # Show errors if any
            if errors:
                if 'doc_type' in errors:
                    st.error(errors['doc_type'])
                if 'file' in errors:
                    st.error(errors['file'])
            else:
                # Upload to S3
                with st.spinner('Uploading file to S3...'):
                    result = upload_to_s3(uploaded_file, directory, BUCKET_NAME)

                    if result['status'] == 'success':
                        st.success(f"**{result['key']}** File uploaded successfully!")
                        st.rerun()
                    else:
                        st.error(f"Upload failed: {result['message']}")

