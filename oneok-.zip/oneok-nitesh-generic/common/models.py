# src/common/models.py
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class DocumentSelection:
    doc1: str
    doc2: str
    doc3: Optional[str] = None

@dataclass
class PromptConfig:
    name: str
    version: str
    prompt_id: str
    search_type: str
