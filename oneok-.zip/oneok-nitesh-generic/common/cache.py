from functools import wraps
import streamlit as st

def st_cache_data(func):
    """
    Custom cache decorator with error handling
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        cache_key = f"{func.__name__}_{str(args)}_{str(kwargs)}"

        if cache_key not in st.session_state:
            try:
                result = func(*args, **kwargs)
                st.session_state[cache_key] = result
            except Exception as e:
                st.error(f"Cache error: {str(e)}")
                return None

        return st.session_state[cache_key]

    return wrapper