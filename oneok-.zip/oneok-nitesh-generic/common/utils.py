# src/common/utils.py
import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

def validate_document_count(count: int) -> bool:
    from .constants import MAX_DOCUMENT_SELECTION, MIN_DOCUMENT_SELECTION
    return MIN_DOCUMENT_SELECTION <= count <= MAX_DOCUMENT_SELECTION

def format_error_message(error: Exception) -> str:
    return f"An error occurred: {str(error)}"

def process_documents(
    documents: List[str],
    prompt_config: Dict,
    search_type: str
) -> Dict:
    """
    Process documents with given configuration

    Args:
        documents (List[str]): List of document paths
        prompt_config (Dict): Prompt configuration
        search_type (str): Type of search to perform

    Returns:
        Dict: Processing results
    """
    # Implement document processing logic
    pass

def display_results(results: Dict):
    """
    Display processing results in the UI

    Args:
        results (Dict): Processing results to display
    """
    # Implement results display logic
    pass
