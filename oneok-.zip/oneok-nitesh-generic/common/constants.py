# src/common/constants.py
from enum import Enum

class SearchType(Enum):
    HYBRID = "HYBRID"
    SEMANTIC = "SEMANTIC"

MAX_DOCUMENT_SELECTION = 3
MIN_DOCUMENT_SELECTION = 2
