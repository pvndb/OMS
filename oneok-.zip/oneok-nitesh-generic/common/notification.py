import streamlit as st

def show_warning(message):
    warning_style = f"""
        <style>
            .custom-warning {{
                background-color: #FFF5F5;
                border-left: 4px solid #FF5757;
                padding: 5px;
                margin: 1rem 0;
                border-radius: 0.35rem;
                color: #DC2626;
                font-size: 0.875rem;
                display: flex;
                align-items: center;
                box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            }}
            .warning-icon {{
                margin-right: 0.75rem;
                font-size: 17px;
            }}
        </style>
        <div class="custom-warning">
            <span class="warning-icon">⚠️
            {message}
        </div>
    """
    st.markdown(warning_style, unsafe_allow_html=True)

# Alternative modern version
def show_warning_modern(message):
    warning_style = f"""
        <style>
            .modern-warning {{
                background-color: #FEF2F2;
                border: 1px solid #FEE2E2;
                padding: 1rem 1.25rem;
                margin: 1rem 0;
                border-radius: 0.5rem;
                display: flex;
                align-items: center;
                gap: 0.75rem;
            }}
            .modern-warning-content {{
                display: flex;
                flex-direction: column;
            }}
            .warning-title {{
                color: #991B1B;
                font-weight: 600;
                font-size: 0.875rem;
                line-height: 1.25rem;
            }}
            .warning-message {{
                color: #B91C1C;
                font-size: 0.875rem;
                line-height: 1.25rem;
                margin-top: 0.25rem;
            }}
        </style>
        <div class="modern-warning">
            <div style="color: #DC2626;">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <line x1="12" y1="8" x2="12" y2="12"></line>
                    <line x1="12" y1="16" x2="12.01" y2="16"></line>
                </svg>
            </div>
            <div class="modern-warning-content">
                <div class="warning-title">Warning</div>
                <div class="warning-message">{message}</div>
            </div>
        </div>
    """
    st.markdown(warning_style, unsafe_allow_html=True)

