import sys
from pathlib import Path
import streamlit as st

# Add the project root to Python path
project_root = str(Path(__file__).parent)
if project_root not in sys.path:
    sys.path.append(project_root)

from frontend.views import render_document_comparison_view

from frontend.components.header import (
    create_horizontal_menu
)

from frontend.components.footer import (
    create_footer
)

def main():
    st.set_page_config(
        page_title="Document Comparison Tool",
        layout="wide",
        initial_sidebar_state="collapsed"
    )

    # Add custom CSS to style the header
    st.markdown("""
        <style>
        .stButton button {
            width: 100%;
            background-color: transparent;
            border: none;
        }
        .stButton button:hover {
            background-color: #f0f2f6;
            border: none;
        }
        </style>
    """, unsafe_allow_html=True)

    # Render the header
    create_horizontal_menu()

    BUCKET_NAME = st.secrets["AWS_S3_BUCKET"]
    render_document_comparison_view(bucket_name=BUCKET_NAME)

    # Add the footer at the end
    create_footer()

if __name__ == "__main__":
    main()